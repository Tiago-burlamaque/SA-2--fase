import { Outlet } from 'react-router-dom';
import './body.css'

function Body(){
    

return(
    <>
    <Outlet />
    </>
)


}
export default Body;