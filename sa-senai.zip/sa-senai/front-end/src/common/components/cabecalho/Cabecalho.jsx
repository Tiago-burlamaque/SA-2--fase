import "./Cabecalho.css";
import Navbar from "../navbar/Navbar";

function Cabecalho () {
    return (

        <header className="cabecalho_root">
            <Navbar />
        </header>
        
    );
}

export default Cabecalho;
